<?php
/*数据库配置*/
$atconfig=array(
	'IP' => 'localhost', //数据库服务器
	'Port' => 3306, //数据库端口
	'User' => '', //数据库用户名
	'Pass' => '', //数据库密码
	'SQLName' => '', //数据库名
	'dbqz' => 'autive' //数据表前缀
);
?>